"""二次元老婆 Gacha（NoneBot2 版）

完整版 `nonebot_plugin_animewifex` 的**精简分支**：保留「抽老婆 / 查老婆 / 换老婆」
三个基础玩法，并新增「十连抽老婆」卡池玩法（Pick Up 保底机制），
适合只需要每日抽老婆、玩腻了其它玩法的群。

Lite 版移除了：

- **命令**：``牛老婆``、``重置牛``、``切换ntr开关状态``、``重置换``、
  ``交换老婆``、``同意交换``、``拒绝交换``、``查看交换请求``
- **配置**：``ntr_max``、``ntr_possibility``、``swap_max_per_day``、
  ``reset_max_uses_per_day``、``reset_success_rate``、``reset_mute_duration``、``admins``
- **数据**：``records.json`` 中的 ``ntr`` / ``reset`` / ``swap`` 分区、``ntr_status.json``、
  ``swap_requests.json``

保留命令共 8 条：``老婆帮助``、``抽老婆``、``查老婆``、``换老婆``、
``十连抽老婆``、``pick up+角色名``、``更换pick up+角色名``，
以及「回复数字」——用于从 Pick Up 候选 / 十连结果中做选择。
另有两处非命令的应答：回复数字、回复「是 / 否」（回答是否把 Pick Up 运用至单抽）。

插件里保留三套抽卡玩法：默认抽老婆（全图库随机）、开启 Pick Up 的单抽
（2% 命中 + 独立保底计数）、十连抽老婆（2% 命中 + 另一套独立保底计数）。

配置前缀与数据目录独立（``ANIMEWIFEX_GACHA_`` / ``animewifex_gacha``），
可与完整版、Lite 版共存互不干扰。

由 AstrBot 插件 `astrbot_plugin_animewifex` 移植而来，业务逻辑、数据格式与
持久化方式保持一致，仅替换框架相关 API：

============================  ==========================================
AstrBot                        NoneBot2
============================  ==========================================
``AstrBotConfig``              ``get_plugin_config(Config)``
``StarTools.get_data_dir``     配置项 ``data_dir`` / NoneBot2 ``data_dir``
``Star`` + ``terminate``       模块导入即初始化 + ``driver.on_shutdown``
``AstrMessageEvent``           ``Event`` / ``Matcher``
``At`` / ``Plain`` / ``Image``  ``MessageSegment.at/text/image``
``filter.event_message_type``  ``on_message`` + 群聊过滤
``event.is_at_or_wake_command``  ``COMMAND_START`` 前缀匹配（``need_prefix``）
============================  ==========================================

注册方式（二者任选）::

    nb-cli plugin install ./nonebot_plugin_aniwifex_gacha

或把整个目录放进 ``src/plugins/aniwifex_gacha/`` 后启动 NoneBot2。
"""

from __future__ import annotations

import asyncio
import os
import random
import re

# 已停用：远程图床取图所需的网络依赖（本地图库模式不再使用）
# import time
# import aiohttp
from collections.abc import Awaitable, Callable
from datetime import timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from nonebot import get_driver, logger, on_message
from nonebot.adapters import Bot, Event, Message, MessageSegment
from nonebot.matcher import Matcher
from nonebot.rule import Rule

from .config import Config, plugin_config
from .storage import (
    DEFAULT_TIMEZONE,
    get_today,
    has_today_wife,
    load_json,
    migrate_wife_data,
    sanitize_gacha_state,
    sanitize_group_records,
    save_json,
    seconds_until_next_midnight,
)

# ==================== 框架适配层 ====================

__all__ = [
    "AnimeWife",
    "Config",
    "anime_wife",
    "anime_wife_matcher",
    "match_command",
    "plugin_config",
]

# 允许「命令 + 参数」之间省略空格的命令（pick up 五河琴里 / pick up五河琴里）
ARG_COMMANDS = {"pick up", "更换pick up"}

# 内部命令名：用户回复数字选择（Pick Up 候选 / 十连结果）
SELECT_COMMAND = "__select__"

# 内部命令名：用户回答「是 / 否」（是否把 Pick Up 一并运用到单抽）
CONFIRM_COMMAND = "__confirm__"

# 「是 / 否」的回答词表（小写比较，英文不区分大小写）
CONFIRM_YES = {"是", "yes", "y"}
CONFIRM_NO = {"否", "no", "n"}

# pick up 之后询问是否把 Pick Up 运用到单抽
SINGLE_PICKUP_QUESTION = "是否将pick up的角色一并运用至单抽？回复「是」或「否」"

# pick up 重名候选过多时的上限，超过则要求用户把角色名写完整
MAX_PICKUP_CANDIDATES = 20

# 图库缺图时引导用户提交 issue 申请扩充
ISSUE_URL = "https://github.com/xiaoyaoyo23333/nonebot_plugin_animewifex_gacha/issues"


def _is_confirm_answer(text: str) -> bool:
    """判断文本是否是「是 / 否」的回答"""
    t = text.strip().lower()
    return t in CONFIRM_YES or t in CONFIRM_NO


def _session_type(event: Event) -> str | None:
    """获取会话类型

    NoneBot2 2.5 移除了 ``Event.get_session_type()``，改为直接读取适配器提供的
    ``message_type`` 字段（OneBot V11 / V12 均为 ``group`` / ``private``）；
    旧版本优先走 ``get_session_type()``，都没有时按 ``group_id`` 兜底。
    """
    getter = getattr(event, "get_session_type", None)
    if callable(getter):
        try:
            return str(getter())
        except Exception:
            pass
    message_type = getattr(event, "message_type", None)
    if isinstance(message_type, str):
        return message_type
    if getattr(event, "group_id", None) is not None:
        return "group"
    return None


def _is_group_event(event: Event) -> bool:
    """判断是否为群聊消息事件"""
    return _session_type(event) == "group"


def _bot_self_id(bot: Bot) -> str:
    """机器人自身账号（NoneBot2 2.5 起 Event 不再提供 get_self_id）"""
    return str(getattr(bot, "self_id", "") or "")


def _seg_cls(event: Event) -> type:
    """获取事件使用的消息段类型

    NoneBot2 2.5 起 text()/at()/image() 等工厂方法只存在于各适配器的
    MessageSegment 子类上，核心基类不再提供，这里统一从事件取当前适配器的段类型。
    """
    try:
        return event.get_message().get_segment_class()
    except Exception:
        return MessageSegment


def _event_user_name(event: Event) -> str:
    """获取发送者昵称

    NoneBot2 2.5 移除了 ``Event.get_user_name()``，此处按适配器字段逐级回退：
    OneBot V11 的 ``sender.card`` / ``sender.nickname``，
    OneBot V12 的 ``member.card`` / ``user.display_name``。
    """
    getter = getattr(event, "get_user_name", None)
    if callable(getter):
        try:
            name = getter()
            if name:
                return str(name).strip()
        except Exception:
            pass
    for container_name in ("sender", "member", "user"):
        container = getattr(event, container_name, None)
        if container is None:
            continue
        for key in ("card", "display_name", "nickname", "name"):
            value = getattr(container, key, None)
            if value:
                return str(value).strip()
    for key in ("nickname", "name"):
        value = getattr(event, key, None)
        if value:
            return str(value).strip()
    return ""


def _command_prefixes() -> tuple[str, ...]:
    """读取 NoneBot2 全局命令前缀配置（.env 中的 COMMAND_START）"""
    try:
        raw = get_driver().config.command_start
    except Exception:
        raw = ("/",)
    if isinstance(raw, str):
        raw = (raw,)
    return tuple(str(p) for p in raw if p)


def _extract_text(event: Event) -> str:
    """提取用于命令匹配的消息文本

    ``get_plaintext()`` 会自动剔除 @ 等非文本消息段，因此 ``@机器人 抽老婆``
    与 ``抽老婆`` 等价，AstrBot 版的「唤醒」语义天然保留。

    ``need_prefix`` 开启时要求以 COMMAND_START 中的前缀开头，并去掉该前缀；
    若 COMMAND_START 含空字符串（默认「所有消息都是命令」）则前缀模式不可用。
    """
    try:
        text = event.get_plaintext().strip()
    except Exception:
        return ""
    if not text or not plugin_config.need_prefix:
        return text
    for prefix in _command_prefixes():
        if text.startswith(prefix):
            return text[len(prefix) :].lstrip()
    return ""


def _parse_at_target(event: Event, self_id: str) -> str | None:
    """解析消息中的 @ 目标用户

    跳过所有指向机器人自身的 At，返回第一个有效的目标用户 ID；未找到时返回 None。
    """
    try:
        segments = event.get_message()
    except Exception:
        return None
    for seg in segments:
        if getattr(seg, "type", None) != "at":
            continue
        data = getattr(seg, "data", None)
        if not isinstance(data, dict):
            continue
        uid = data.get("qq") or data.get("user_id")
        if uid is None:
            continue
        uid = str(uid)
        if uid and uid != self_id:
            return uid
    return None


def _build_message(event: Event, segments: list[MessageSegment]) -> Message:
    """用事件自带的消息类组装消息，保证与适配器的类型一致"""
    try:
        message_cls: type[Message] = type(event.get_message())
    except Exception:
        message_cls = Message
    return message_cls(segments)


def _text_seg(event: Event, text: str) -> MessageSegment:
    """构建文本消息段"""
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "text", None)
    if callable(factory):
        try:
            return factory(text)
        except Exception:
            pass
    return seg_cls("text", {"text": text})


def _at_seg(event: Event, user_id: str) -> MessageSegment:
    """构建 @ 消息段"""
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "at", None)
    if callable(factory):
        try:
            return factory(user_id)
        except Exception:
            pass
    return seg_cls("at", {"qq": str(user_id)})


def _image_seg(
    event: Event, *, file: str | None = None, url: str | None = None
) -> MessageSegment:
    """构建图片消息段（本地文件优先用适配器的 image()，远程链接走 url 字段）"""
    seg_cls = _seg_cls(event)
    if file:
        factory = getattr(seg_cls, "image", None)
        if callable(factory):
            try:
                return factory(file)
            except Exception:
                pass
        return seg_cls("image", {"file": str(file)})
    return seg_cls("image", {"url": url})


def _reply_seg(event: Event) -> MessageSegment | None:
    """构建「引用回复」消息段（QQ 引用）

    OneBot V11 的 reply 段数据键是 ``id``，V12 是 ``message_id``，两者字段名不同，
    因此统一走适配器自带的 ``reply()`` 工厂构造；工厂不存在时才按标准字段兜底。

    事件里拿不到 message_id（部分适配器不提供）时返回 None，调用方退化为普通消息。
    """
    message_id = getattr(event, "message_id", None)
    if message_id is None:
        return None
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "reply", None)
    if callable(factory):
        for args in ((message_id,), (message_id, str(event.get_user_id()))):
            try:
                return factory(*args)
            except Exception:
                continue
    for key in ("id", "message_id"):
        try:
            return seg_cls("reply", {key: str(message_id)})
        except Exception:
            continue
    return None


# ==================== 主插件逻辑 ====================


class AnimeWife:
    """二次元老婆插件主类（原 AstrBot ``WifePlugin``）"""

    def __init__(self) -> None:
        self._init_config()
        self._init_commands()
        self._init_storage()
        self._daily_cleanup_task: asyncio.Task | None = None

    # ==================== 初始化 ====================

    def _init_config(self) -> None:
        """初始化配置参数（带默认值兜底，避免配置缺项导致加载失败）"""
        self.tz = self._resolve_timezone()
        self.need_prefix = bool(plugin_config.need_prefix)
        self.change_max_per_day = plugin_config.change_max_per_day

        # ---- 十连抽老婆 ----
        self.pickup_rate = min(max(float(plugin_config.pickup_rate), 0.0), 1.0)
        self.pity_limit = max(int(plugin_config.pity_limit), 1)
        self.ten_draw_count = max(int(plugin_config.ten_draw_count), 1)

        # ---- 已停用：远程图床配置（本地图库模式不再需要）----
        # base_url = plugin_config.image_base_url or "https://cdn.jsdmirror.com/gh/monbed/wife@main"
        # self.image_base_url = base_url.rstrip("/") + "/"
        # self.image_list_url = (
        #     plugin_config.image_list_url or "https://animewife.dpdns.org/list.txt"
        # )

    def _resolve_timezone(self) -> ZoneInfo:
        """解析判定「今天」所用的时区

        优先级：``ANIMEWIFEX_TIMEZONE`` > NoneBot2 全局 ``timezone`` > 环境变量 ``TZ``
        > ``Asia/Shanghai``。

        Windows 的 Python 默认不带 IANA 时区库（NoneBot2 也不依赖 ``tzdata``），
        此时 ``ZoneInfo`` 会抛 ``ZoneInfoNotFoundError``；这里逐个候选尝试，
        全部失败后退回固定 UTC+8，保证插件始终能正常加载，不会因缺少可选依赖而崩溃。
        """
        candidates: list[str] = []
        tz_name = str(plugin_config.timezone or "").strip()
        if tz_name:
            candidates.append(tz_name)
        try:
            global_tz = str(getattr(get_driver().config, "timezone", "") or "").strip()
        except Exception:
            global_tz = ""
        if global_tz:
            candidates.append(global_tz)
        env_tz = os.environ.get("TZ", "").strip()
        if env_tz:
            candidates.append(env_tz)
        candidates.append(DEFAULT_TIMEZONE)

        for name in candidates:
            try:
                return ZoneInfo(name)
            except Exception:
                logger.error(f"时区 {name!r} 不可用，尝试下一个回退值")

        # 连 tzdata 都没装时的最终兜底：东八区固定偏移
        logger.warning(
            "未找到可用的 IANA 时区数据（是否缺少 tzdata？），已回退固定 UTC+8"
        )
        return timezone(timedelta(hours=8))  # type: ignore[return-value]

    def _resolve_data_dir(self) -> Path:
        """插件数据目录

        优先 ``ANIMEWIFEX_GACHA_DATA_DIR``；其次 NoneBot2 全局
        ``data_dir/animewifex_gacha``；全局也未配置时退回项目目录下约定俗成的
        ``data/animewifex_gacha``。
        """
        raw = str(plugin_config.data_dir or "").strip()
        if raw:
            path = Path(raw).expanduser()
            return path if path.is_absolute() else Path.cwd() / path
        try:
            base = str(getattr(get_driver().config, "data_dir", "") or "").strip()
        except Exception:
            base = ""
        if not base:
            base = "data"  # NoneBot2 历史默认的数据目录
        path = Path(base).expanduser()
        if not path.is_absolute():
            path = Path.cwd() / path
        return path / "animewifex_gacha"

    def _init_commands(self) -> None:
        """初始化命令映射表"""
        self.commands: dict[str, Callable[[Event, Bot, Matcher], Awaitable[None]]] = {
            "老婆帮助": self.wife_help,
            "抽老婆": self.animewife,
            "查老婆": self.search_wife,
            "换老婆": self.change_wife,
            "十连抽老婆": self.ten_draw_wife,
            "pick up": self.pickup_wife,
            "更换pick up": self.change_pickup_wife,
        }
        # 按命令名长度降序排列，匹配时避免较短的命令意外截胡更长的命令
        self.command_names = sorted(self.commands, key=len, reverse=True)

    def _init_storage(self) -> None:
        """初始化数据目录并加载持久化数据"""
        plugin_dir = self._resolve_data_dir()
        self.config_dir = plugin_dir / "config"
        self.img_dir = plugin_dir / "img" / "wife"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.img_dir.mkdir(parents=True, exist_ok=True)

        self.records_file = self.config_dir / "records.json"
        # 已停用：远程图片列表缓存（本地图库模式不再需要）
        # self.wife_list_cache_file = self.config_dir / "wife_list_cache.txt"

        # 图库文件列表缓存：(目录 mtime, 文件名列表)
        self._lib_cache: tuple[float, list[str]] | None = None

        # 群组级状态锁：保护该群的老婆配置与次数记录
        self.group_locks: dict[str, asyncio.Lock] = {}

        raw = load_json(self.records_file)
        # change=换老婆次数
        self.records = {
            key: sanitize_group_records(raw.get(key), f"records.json[{key}]")
            for key in ("change",)
        }
        # 启动阶段尚无并发，清理无需加锁；校验丢弃过非法条目时同样需要落盘
        today = get_today(self.tz)
        changed = any(self.records[key] != raw.get(key, {}) for key in self.records)
        for gid in {gid for recs in self.records.values() for gid in recs}:
            changed |= self._prune_group_records(gid, today)
        if changed:
            self.save_records()

    # ==================== 并发与持久化 ====================

    def get_group_lock(self, group_id: str) -> asyncio.Lock:
        """获取或创建群组级状态锁"""
        if group_id not in self.group_locks:
            self.group_locks[group_id] = asyncio.Lock()
        return self.group_locks[group_id]

    def save_records(self) -> None:
        save_json(self.records_file, self.records)

    def _prune_group_records(self, gid: str, today: str) -> bool:
        """删除某群各类别中日期不是今天的次数记录，群内清空后移除该群条目，返回是否有变动

        处理协程可能在群锁内持有群记录字典的引用跨越 await 点，
        运行期调用必须先持有该群的锁，避免删除群条目后协程写入悬空字典。
        """
        changed = False
        for recs in self.records.values():
            grp = recs.get(gid)
            if grp is None:
                continue
            stale = [uid for uid, rec in grp.items() if rec.get("date") != today]
            for uid in stale:
                del grp[uid]
            if stale or not grp:
                changed = True
            if not grp:
                del recs[gid]
        return changed

    def load_group_config(self, group_id: str) -> dict:
        """加载群组配置，旧版列表格式的老婆数据自动迁移为字典，无法识别的条目丢弃"""
        raw = load_json(self.config_dir / f"{group_id}.json")
        cfg = {}
        for uid, data in raw.items():
            wife = migrate_wife_data(data)
            if wife is not None:
                cfg[uid] = wife
        return cfg

    def save_group_config(self, group_id: str, cfg: dict) -> None:
        save_json(self.config_dir / f"{group_id}.json", cfg)

    # ==================== 通用辅助 ====================

    @staticmethod
    def _uid(event: Event) -> str:
        return str(event.get_user_id())

    @staticmethod
    def _gid(event: Event) -> str:
        return str(getattr(event, "group_id"))

    @staticmethod
    def _nick(event: Event) -> str:
        return _event_user_name(event) or str(event.get_user_id())

    async def _send_all(self, matcher: Matcher, replies: list[Any]) -> None:
        """依次发送收集好的回复"""
        for reply in replies:
            await matcher.send(reply)

    # ==================== 目标解析 ====================

    def parse_target(self, event: Event, text: str, bot: Bot) -> str | None:
        """解析命令目标用户：优先 @ ，其次「查老婆 昵称」形式的昵称匹配"""
        target = _parse_at_target(event, _bot_self_id(bot))
        if target:
            return target

        if text.startswith("查老婆"):
            parts = text.split(maxsplit=1)
            if len(parts) > 1:
                name = parts[1]
                cfg = self.load_group_config(self._gid(event))
                for uid, wife in cfg.items():
                    if wife.get("owner") == name:
                        return uid
        return None

    # ==================== 抽老婆与查询 ====================

    async def animewife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """抽老婆

        三套抽卡之一：默认抽法。没设 Pick Up、或用户没同意把 Pick Up 运用到单抽时，
        就是从全图库随机抽一个；同意之后改走 Pick Up 概率与单抽自己的保底计数。
        """
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        locked = False
        img = ""
        is_up = False
        async with self.get_group_lock(gid):
            cfg = self.load_group_config(gid)
            wife = cfg.get(uid)
            if (
                isinstance(wife, dict)
                and wife.get("date") == today
                and wife.get("locked")
            ):
                # 十连抽老婆得到的老婆不可更换
                locked = True
            else:
                if not has_today_wife(cfg, uid, today):
                    img, is_up = await self._roll_single_draw(gid, uid)
                    if img:
                        rec: dict[str, Any] = {
                            "img": img,
                            "date": today,
                            "owner": nick,
                        }
                        if is_up:
                            # 单抽命中 Pick Up：与十连一致，今天的老婆锁定不可更换
                            rec["locked"] = True
                            rec["source"] = "gacha"
                        cfg[uid] = rec
                        self.save_group_config(gid, cfg)
                else:
                    img = cfg[uid]["img"]

        if locked:
            await matcher.finish(
                f"{nick}，你不是抽到老婆了嘛~杂鱼杂鱼~"
            )
        if not img:
            await matcher.finish(
                self._build_reply_message(
                    event, "抱歉，今天的老婆获取失败了，请稍后再试~"
                )
            )
        await matcher.finish(self._build_wife_message(event, img, nick, is_up))

    async def search_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """查老婆"""
        gid = self._gid(event)
        text = _extract_text(event)
        tid = self.parse_target(event, text, bot) or self._uid(event)
        today = get_today(self.tz)

        cfg = self.load_group_config(gid)

        if not has_today_wife(cfg, tid, today):
            await matcher.finish("没有发现老婆的踪迹，快去抽一个试试吧~")

        img = cfg[tid]["img"]
        owner = cfg[tid].get("owner", "未知用户")
        chara, source = self._parse_wife_name(img)
        if source:
            text_out = f"{owner}的老婆是来自《{source}》的{chara}，羡慕吗？"
        else:
            text_out = f"{owner}的老婆是{chara}，羡慕吗？"
        await matcher.finish(self._build_chain(event, text_out, img))

    async def _fetch_wife_image(self) -> str | None:
        """从本地图库随机抽取一张图片

        现为**纯本地模式**：只扫描 <数据目录>/img/wife/ 下的文件，不做任何网络请求。
        图库为空时返回 None，由调用方给出「获取失败」的提示。
        """
        try:
            with os.scandir(self.img_dir) as entries:
                local_imgs = [e.name for e in entries if e.is_file()]
            if local_imgs:
                return random.choice(local_imgs)
        except OSError:
            pass

        logger.warning(f"本地图库为空或不可读，请在 {self.img_dir} 放入图片后再试")
        return None

        # ------------------------------------------------------------------
        # 以下为已停用的「远程图床」取图逻辑（依赖 image_list_url + 网络列表缓存）。
        # 如需恢复：还原本段、_init_config 中的 image_list_url 配置、
        # _build_image_segment 中的 URL 回退分支，以及 time / aiohttp 导入。
        # ------------------------------------------------------------------
        # cached_lines: list[str] = []
        # cache_expired = True
        # if self.wife_list_cache_file.exists():
        #     try:
        #         cache_expired = (
        #             time.time() - self.wife_list_cache_file.stat().st_mtime
        #         ) >= 3600
        #         with open(self.wife_list_cache_file, "r", encoding="utf-8") as f:
        #             cached_lines = [
        #                 s for s in (line.strip() for line in f.read().splitlines()) if s
        #             ]
        #     except (OSError, UnicodeDecodeError):
        #         pass
        #
        # if not cache_expired and cached_lines:
        #     return random.choice(cached_lines)
        #
        # try:
        #     timeout = aiohttp.ClientTimeout(total=10)
        #     async with aiohttp.ClientSession(timeout=timeout) as session:
        #         async with session.get(self.image_list_url) as resp:
        #             if resp.status == 200:
        #                 text = await resp.text()
        #                 lines = [
        #                     s for s in (line.strip() for line in text.splitlines()) if s
        #                 ]
        #                 if lines:
        #                     try:
        #                         with open(
        #                             self.wife_list_cache_file, "w", encoding="utf-8"
        #                         ) as f:
        #                             f.write("\n".join(lines))
        #                     except OSError:
        #                         pass
        #                     return random.choice(lines)
        # except Exception:
        #     pass
        #
        # if cached_lines:
        #     return random.choice(cached_lines)
        # return None

    async def _roll_single_draw(self, gid: str, uid: str) -> tuple[str | None, bool]:
        """单抽一次，返回 (图片名, 是否命中 Pick Up)

        没设 Pick Up、或用户没同意把 Pick Up 运用到单抽时，就是原来的纯随机抽取，
        不计任何保底；同意之后按 ``pickup_rate`` 命中 Pick Up，累计抽数达到
        ``pity_limit`` 时必出，命中后**单抽自己的**累计抽数清零——与十连抽的
        累计抽数分开记，互不影响。
        """
        state = self.load_gacha_state(gid)
        me = state.setdefault(uid, {})
        pickup = me.get("pickup")
        enabled = bool(me.get("single_pickup")) and bool(pickup)
        # 答案绑定的是设置问题时的 Pick Up 目标；目标换了答案就作废
        if enabled and me.get("single_target") != pickup:
            enabled = False
        if not enabled:
            return await self._fetch_wife_image(), False

        files = self._library_files()
        if not files or pickup not in files:
            return await self._fetch_wife_image(), False

        others = [f for f in files if f != pickup]
        count = int(me.get("single_count", 0))
        hit = count >= self.pity_limit - 1 or not others
        if not hit:
            hit = random.random() < self.pickup_rate
        img = pickup if hit else random.choice(others)
        me["single_count"] = 0 if hit else count + 1
        self.save_gacha_state(gid, state)
        return img, hit

    @staticmethod
    def _parse_wife_name(img: str) -> tuple[str, str | None]:
        """从图片标识解析出 (角色名, 作品来源)，无来源时来源为 None"""
        name = os.path.splitext(img)[0].split("/")[-1]
        if "!" in name:
            source, chara = name.split("!", 1)
            return chara, source
        return name, None

    def _build_image_segment(self, event: Event, img: str) -> MessageSegment | None:
        """根据图片标识构建图片消息段（仅本地图库）"""
        # 图片标识来自群配置，读取前校验路径未逃逸出图库目录
        try:
            base = os.path.abspath(self.img_dir)
            path = os.path.abspath(os.path.join(base, img))
            # Windows 下跨盘符会让 commonpath 抛 ValueError，按「不在图库内」处理
            if os.path.commonpath([base, path]) == base and os.path.isfile(path):
                return _image_seg(event, file=path)
        except (ValueError, OSError):
            pass

        logger.warning(f"本地图库中找不到图片，已跳过：{img}")
        return None

        # 已停用的远程 URL 回退分支，如需恢复见 _fetch_wife_image 的说明
        # try:
        #     return _image_seg(event, url=self.image_base_url + img)
        # except Exception:
        #     logger.exception("构建图片消息段失败")
        #     return None

    def _build_chain(self, event: Event, text: str, img: str) -> Message:
        """构建「文字 + 图片」消息，图片段构建失败时仅保留文字"""
        parts = [_text_seg(event, text)]
        img_seg = self._build_image_segment(event, img)
        if img_seg is not None:
            parts.append(img_seg)
        return _build_message(event, parts)

    def _build_reply_message(self, event: Event, text: str) -> Message:
        """构建「引用 + 文字」消息

        用于不带用户名的回复（引导类、结果类），在 QQ 里表现为引用用户的原消息，
        避免刷屏时看不出这条回复是在回应谁。
        适配器不支持引用时退化为纯文字消息。
        """
        parts: list[MessageSegment] = []
        reply_seg = _reply_seg(event)
        if reply_seg is not None:
            parts.append(reply_seg)
        parts.append(_text_seg(event, text))
        return _build_message(event, parts)

    def _build_wife_message(
        self, event: Event, img: str, nick: str, is_up: bool = False
    ) -> Message:
        """构建「你今天的老婆是…」消息

        is_up 为真时额外标注「（pick up角色）」。单抽的保底进度属于后台细节，
        正常情况下完全不显示，只有真的命中 Pick Up 才提示。
        """
        chara, source = self._parse_wife_name(img)
        mark = "（pick up角色）" if is_up else ""
        if source:
            text = f"{nick}，你今天的老婆是来自《{source}》的{chara}{mark}，请好好珍惜哦~"
        else:
            text = f"{nick}，你今天的老婆是{chara}{mark}，请好好珍惜哦~"
        if is_up:
            text += "\n今天的老婆已锁定不可更换哦~"
        return self._build_chain(event, text, img)

    # ==================== 帮助命令 ====================

    async def wife_help(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """显示帮助信息"""
        help_text = """
【基础命令】
• 抽老婆 - 每天抽取一个二次元老婆
• 查老婆 [@用户] - 查看别人的老婆

【换老婆功能】
• 换老婆 - 丢弃当前老婆换新的

【Pick Up 与十连抽老婆】
• pick up+角色名 - 指定 Pick Up 老婆（十连命中概率提升为 2%）
• 更换pick up+角色名 - 更换 Pick Up 老婆
• 十连抽老婆 - 每天一次十连，满 120 抽必出 Pick Up
• 设好 Pick Up 后会追问是否一并运用至单抽，回复「是」或「否」

💡 提示：换老婆有每日使用次数限制
"""
        await matcher.finish(self._build_reply_message(event, help_text.strip()))

    # ==================== 换老婆相关 ====================

    async def change_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """换老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        # 次数检查、自增与更换老婆在同一临界区内完成，避免并发绕过每日上限
        async with self.get_group_lock(gid):
            recs = self.records["change"].setdefault(gid, {})
            rec = recs.get(uid, {"date": "", "count": 0})

            cfg = self.load_group_config(gid)
            wife = cfg.get(uid)
            if (
                isinstance(wife, dict)
                and wife.get("date") == today
                and wife.get("locked")
            ):
                # 十连抽老婆得到的老婆不可更换
                replies.append(
                    f"{nick}，你不是抽到老婆了嘛~杂鱼杂鱼~"
                )
            elif rec["date"] == today and rec["count"] >= self.change_max_per_day:
                replies.append(
                    f"{nick}，你今天已经换了{self.change_max_per_day}次老婆啦，明天再来吧~"
                )
            elif not has_today_wife(cfg, uid, today):
                replies.append(f"{nick}，你今天还没有老婆，先去抽一个再来换吧~")
            else:
                # 先抽到新老婆再替换；抽取失败时老婆和次数都保持不动
                img = await self._fetch_wife_image()
                if not img:
                    replies.append(
                        self._build_reply_message(
                            event, "抱歉，新老婆获取失败了，本次更换未生效，请稍后再试~"
                        )
                    )
                else:
                    cfg[uid] = {"img": img, "date": today, "owner": nick}
                    self.save_group_config(gid, cfg)

                    if rec["date"] != today:
                        rec = {"date": today, "count": 1}
                    else:
                        rec["count"] += 1
                    recs[uid] = rec
                    self.save_records()

                    replies.append(self._build_wife_message(event, img, nick))

        await self._send_all(matcher, replies)

    # ==================== 十连抽老婆 ====================

    # ---- 图库索引与名字解析 ----

    def _library_files(self) -> list[str]:
        """扫描本地图库，返回文件名列表

        以目录 mtime 作为缓存键：往图库里增删图片会更新目录 mtime，
        缓存随之失效，所以手动补图后不需要重启插件。

        图库约定所有图片按 ``作品名!角色名.jpg`` 命名；不符合该规范的文件不会被
        丢弃（避免误删用户素材），但会打一条 warning 提示改名，并且其文案不显示
        作品来源。
        """
        try:
            mtime = os.stat(self.img_dir).st_mtime
        except OSError:
            return []
        if self._lib_cache is not None and self._lib_cache[0] == mtime:
            return self._lib_cache[1]
        try:
            with os.scandir(self.img_dir) as entries:
                files = sorted(e.name for e in entries if e.is_file())
        except OSError:
            files = []
        self._lib_cache = (mtime, files)
        self._warn_bad_naming(files)
        return files

    @staticmethod
    def _warn_bad_naming(files: list[str]) -> None:
        """提示图库里不符合「作品名!角色名」命名规范的文件"""
        bad = [name for name in files if "!" not in os.path.splitext(name)[0]]
        if not bad:
            return
        shown = "、".join(bad[:5])
        more = f" 等 {len(bad)} 个" if len(bad) > 5 else ""
        logger.warning(
            f"图库中有{more}文件不符合「作品名!角色名」命名规范，"
            f"其文案将不显示作品来源，建议改名：{shown}"
        )

    @staticmethod
    def _split_img_name(img: str) -> tuple[str | None, str]:
        """把图库文件名拆成 (作品名, 角色名)

        命名格式为 ``作品名!角色名.jpg``；图库约定如此，
        缺少 ``!`` 的文件视为命名不规范，作品名为 None（文案不显示作品）。
        """
        name = os.path.splitext(img)[0]
        if "!" in name:
            source, chara = name.split("!", 1)
            return source.strip() or None, chara.strip()
        return None, name.strip()

    @classmethod
    def _display_name(cls, img: str, with_ext: bool = False) -> str:
        """图库文件名 → 展示用名字：《作品名》角色名[.ext]"""
        source, chara = cls._split_img_name(img)
        ext = os.path.splitext(img)[1] if with_ext else ""
        if source:
            return f"《{source}》{chara}{ext}"
        return f"{chara}{ext}"

    @staticmethod
    def _parse_wife_input(raw: str) -> tuple[str | None, str]:
        """解析用户输入的角色名

        支持三种写法：``五河琴里``、``《约会大作战》五河琴里``、``约会大作战!五河琴里``。
        """
        text = raw.strip()
        if text.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".gif")):
            text = os.path.splitext(text)[0]
        matched = re.match(r"^《\s*(.+?)\s*》\s*(.*)$", text)
        if matched:
            source = matched.group(1).strip()
            chara = matched.group(2).strip()
            return (source or None), chara
        if "!" in text:
            source, chara = text.split("!", 1)
            return source.strip() or None, chara.strip()
        return None, text

    def _match_library(self, raw: str) -> list[str]:
        """按用户输入匹配图库文件，返回候选文件名列表

        先精确匹配（角色名完全相同），没有再用包含匹配兜底；
        「同名但作品不同」「同名但扩展名不同」都会作为多个候选交给用户选数字。
        """
        files = self._library_files()
        if not files:
            return []
        source, chara = self._parse_wife_input(raw)
        if not chara:
            return []
        exact: list[str] = []
        loose: list[str] = []
        for img in files:
            img_source, img_chara = self._split_img_name(img)
            if img_chara != chara:
                # 没指定作品名时，允许「角色名包含输入」的模糊匹配兜底
                if not source and chara in img_chara:
                    loose.append(img)
                continue
            if source:
                if img_source == source:
                    exact.append(img)
                else:
                    # 角色名相同但作品不同：作为候选让用户选
                    loose.append(img)
            else:
                exact.append(img)
        return exact or loose

    # ---- 十连抽状态存储 ----

    def _gacha_file(self, group_id: str) -> Path:
        """十连抽状态文件（按群分文件，与老婆记录分开存放）"""
        return self.config_dir / f"gacha_{group_id}.json"

    def load_gacha_state(self, group_id: str) -> dict:
        """加载该群的十连抽状态 {用户: 状态}"""
        return sanitize_gacha_state(
            load_json(self._gacha_file(group_id)), f"gacha_{group_id}.json"
        )

    def save_gacha_state(self, group_id: str, state: dict) -> None:
        """保存该群的十连抽状态"""
        save_json(self._gacha_file(group_id), state)

    def has_pending_selection(self, event: Event) -> bool:
        """判断该用户当前是否有待选择的列表（Pick Up 候选 / 十连结果）"""
        gid = self._gid(event)
        uid = self._uid(event)
        today = get_today(self.tz)
        state = self.load_gacha_state(gid)
        me = state.get(uid)
        if not isinstance(me, dict):
            return False
        pending = me.get("pending")
        if not isinstance(pending, dict):
            return False
        return (
            pending.get("kind") in ("gacha", "pickup")
            and pending.get("date") == today
            and bool(pending.get("options"))
        )

    def has_pending_confirm(self, event: Event) -> bool:
        """判断该用户当前是否有待回答的「是否运用至单抽」问题"""
        gid = self._gid(event)
        uid = self._uid(event)
        today = get_today(self.tz)
        me = self.load_gacha_state(gid).get(uid)
        if not isinstance(me, dict):
            return False
        ask = me.get("ask")
        if not isinstance(ask, dict):
            return False
        return ask.get("date") == today

    def _ask_single_pickup(self, me: dict, today: str) -> str:
        """登记「是否把 Pick Up 运用到单抽」的待答问题，返回问题文案

        答案绑定当前 Pick Up 目标：换了目标就作废旧答案（单抽退回原始抽法），
        同一目标则保留旧答案，直到用户重新回答。

        待答问题单独放在 ``ask`` 字段里，不与「回复数字选列表」的 ``pending``
        抢同一个位置——两者可能同时存在（先 pick up 再抽十连）。
        """
        pickup = me.get("pickup", "")
        if me.get("single_target") != pickup:
            me["single_pickup"] = False
        me["single_target"] = pickup
        me["ask"] = {"date": today}
        return SINGLE_PICKUP_QUESTION

    async def confirm_single_pickup(
        self, event: Event, bot: Bot, matcher: Matcher
    ) -> None:
        """用户回答「是 / 否」：是否把 Pick Up 角色一并运用到单抽"""
        gid = self._gid(event)
        uid = self._uid(event)
        today = get_today(self.tz)
        yes = _extract_text(event).strip().lower() in CONFIRM_YES

        reply = ""
        async with self.get_group_lock(gid):
            state = self.load_gacha_state(gid)
            me = state.setdefault(uid, {})
            ask = me.get("ask")
            if not (isinstance(ask, dict) and ask.get("date") == today):
                reply = "没有待回答的问题哦~"
            else:
                me.pop("ask", None)
                me["single_pickup"] = yes
                me["single_target"] = me.get("pickup", "")
                self.save_gacha_state(gid, state)
                if yes:
                    reply = (
                        "好的，之后的「抽老婆」也会按 Pick Up 概率出图啦"
                        "（单抽的保底与十连分开计数）"
                    )
                else:
                    reply = "好的，单抽维持原始抽法，不套用 Pick Up~"
        await matcher.finish(self._build_reply_message(event, reply))

    # ---- Pick Up ----

    @classmethod
    def _pickup_set_message(cls, img: str) -> str:
        """设置 Pick Up 成功后的提示"""
        return (
            f"已将pick up老婆设置成{cls._display_name(img)}\n"
            "可随时发送“更换pick up+老婆名”更换pick up 老婆"
        )

    async def pickup_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """pick up+角色名：指定 Pick Up 老婆"""
        await self._do_pickup(event, bot, matcher, change=False)

    async def change_pickup_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """更换pick up+角色名：更换 Pick Up 老婆"""
        await self._do_pickup(event, bot, matcher, change=True)

    async def _do_pickup(
        self, event: Event, bot: Bot, matcher: Matcher, *, change: bool
    ) -> None:
        """设置 / 更换 Pick Up 老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        today = get_today(self.tz)
        prefix = "更换pick up" if change else "pick up"
        name = _extract_text(event)[len(prefix) :].strip()

        if not name:
            await matcher.finish(
                self._build_reply_message(
                    event, "请使用“pick up+角色名”的格式指定老婆，例如：pick up 五河琴里"
                )
            )

        candidates = self._match_library(name)
        if not candidates:
            await matcher.finish(
                self._build_reply_message(
                    event,
                    "图库暂无该老婆，请pick up其他老婆"
                    f"\n可提交issue申请扩充：{ISSUE_URL}",
                )
            )
        if len(candidates) > MAX_PICKUP_CANDIDATES:
            await matcher.finish(
                self._build_reply_message(
                    event, f"匹配到 {len(candidates)} 个老婆，请把角色名写得更完整一点~"
                )
            )

        replies: list[Any] = []
        async with self.get_group_lock(gid):
            state = self.load_gacha_state(gid)
            me = state.setdefault(uid, {})
            if len(candidates) == 1:
                me["pickup"] = candidates[0]
                me.pop("pending", None)
                # 设好 Pick Up 后追问一次：要不要一并运用到单抽
                question = self._ask_single_pickup(me, today)
                self.save_gacha_state(gid, state)
                replies.append(
                    self._build_reply_message(
                        event, self._pickup_set_message(candidates[0])
                    )
                )
                replies.append(self._build_reply_message(event, question))
            else:
                # 重名：列出候选，等用户回复数字
                me["pending"] = {
                    "kind": "pickup",
                    "date": today,
                    "options": candidates,
                }
                self.save_gacha_state(gid, state)
                lines = ["你pick up 的是?"]
                for idx, img in enumerate(candidates, 1):
                    lines.append(f"{idx}.{self._display_name(img, with_ext=True)}")
                lines.append("回复数字进行pick up")
                replies.append(self._build_reply_message(event, "\n".join(lines)))

        await self._send_all(matcher, replies)

    # ---- 十连抽 ----

    def _roll_ten_draw(
        self, files: list[str], pickup: str, count: int
    ) -> tuple[list[tuple[str, bool]], str | None, int]:
        """执行一次十连抽

        返回 (结果列表, 抽中 Pick Up 的图片, 最新累计抽数)。

        规则：单抽命中 Pick Up 的概率为 ``pickup_rate``（默认 2%），其余 98% 均分；
        累计抽数达到 ``pity_limit - 1`` 时本抽必出 Pick Up；命中后抽数立刻清零，
        本次十连剩余抽数按新的计数继续抽。
        """
        others = [f for f in files if f != pickup]
        results: list[tuple[str, bool]] = []
        up_img: str | None = None
        for _ in range(self.ten_draw_count):
            hit = count >= self.pity_limit - 1 or not others
            if not hit:
                hit = random.random() < self.pickup_rate
            img = pickup if hit else random.choice(others)
            count += 1
            if hit:
                # 抽中 Pick Up：抽数在这一刻清零
                count = 0
                up_img = img
            results.append((img, hit))
        return results, up_img, count

    def _format_ten_result(
        self, results: list[tuple[str, bool]], count: int
    ) -> str:
        """十连抽结果文案"""
        lines = ["【十连抽老婆】结果："]
        for idx, (img, is_up) in enumerate(results, 1):
            name = self._display_name(img)
            if is_up:
                name += " （pick up！）"
            lines.append(f"{idx}.{name}")
        remain = max(self.pity_limit - count, 0)
        lines.append("")
        lines.append(f"已完成{count}次抽，剩余{remain}次必出pick up")
        return "\n".join(lines)

    def _build_locked_wife_message(
        self, event: Event, img: str, nick: str, via: str = "自选"
    ) -> Message:
        """构建十连锁定今天的老婆的消息（带锁定来源说明）

        via 是锁定来源后缀：十连自选为「自选」，十连直接命中 Pick Up 为「必出Pick Up」。
        两者都要如实说明来源，不能一律写成「自选」。
        """
        chara, source = self._parse_wife_name(img)
        if source:
            text = f"{nick}，你今天的老婆是来自《{source}》的{chara}（通过十连抽{via}）"
        else:
            text = f"{nick}，你今天的老婆是{chara}（通过十连抽{via}）"
        return self._build_chain(event, text, img)

    async def ten_draw_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """十连抽老婆：每天一次，10 次独立单抽"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        async with self.get_group_lock(gid):
            state = self.load_gacha_state(gid)
            me = state.setdefault(uid, {})
            pending = me.get("pending")
            if isinstance(pending, dict) and pending.get("date") != today:
                # 跨天后昨天的待选列表失效
                me.pop("pending", None)

            if me.get("ten_date") == today:
                replies.append(f"{nick}，你今天已经抽过一次十连了，明天再来吧~")
            else:
                pickup = me.get("pickup")
                if not pickup:
                    replies.append(
                        self._build_reply_message(
                            event, "你还未pick up老婆，请使用“pick up+角色名”进行pick up"
                        )
                    )
                else:
                    files = self._library_files()
                    if not files:
                        replies.append(
                            self._build_reply_message(
                                event, "图库为空，请先往图库目录放入图片后再试~"
                            )
                        )
                    elif pickup not in files:
                        me.pop("pickup", None)
                        replies.append(
                            self._build_reply_message(
                                event,
                                "你的pick up老婆已不在图库，"
                                "请重新发送“pick up+角色名”进行pick up",
                            )
                        )
                    else:
                        results, up_img, count = self._roll_ten_draw(
                            files, pickup, int(me.get("count", 0))
                        )
                        me["count"] = count
                        me["ten_date"] = today
                        text = self._format_ten_result(results, count)
                        if up_img:
                            # 出 Pick Up：今天的老婆直接锁定为该卡，无需自选
                            me.pop("pending", None)
                            cfg = self.load_group_config(gid)
                            cfg[uid] = {
                                "img": up_img,
                                "date": today,
                                "owner": nick,
                                "locked": True,
                                "source": "gacha",
                            }
                            self.save_group_config(gid, cfg)
                            text += "\n本次十连已出pick up老婆，今日不可从结果中自选"
                            text += "\n可发送“更换pick up+老婆名”更换pick up 老婆"
                            replies.append(self._build_reply_message(event, text))
                            replies.append(
                                self._build_locked_wife_message(
                                    event, up_img, nick, "必出Pick Up"
                                )
                            )
                        else:
                            # 没出 Pick Up：从 10 张结果里自选一张作为今天的老婆
                            me["pending"] = {
                                "kind": "gacha",
                                "date": today,
                                "options": [img for img, _ in results],
                            }
                            text += "\n已完成十连抽老婆，回复数字以选取今天的老婆"
                            replies.append(self._build_reply_message(event, text))

            if state:
                self.save_gacha_state(gid, state)

        await self._send_all(matcher, replies)

    async def select_pending(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """用户回复数字：从 Pick Up 候选 / 十连结果中做选择"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)
        text = _extract_text(event)
        if not (text.isascii() and text.isdigit()):
            return
        number = int(text)

        replies: list[Any] = []
        async with self.get_group_lock(gid):
            state = self.load_gacha_state(gid)
            me = state.setdefault(uid, {})
            pending = me.get("pending")
            if not (
                isinstance(pending, dict)
                and pending.get("kind") in ("gacha", "pickup")
                and pending.get("date") == today
            ):
                replies.append(
                    self._build_reply_message(event, "没有待选择的内容哦~")
                )
            else:
                options = pending.get("options") or []
                if number < 1 or number > len(options):
                    replies.append(
                        self._build_reply_message(
                            event, f"请回复 1-{len(options)} 之间的数字进行选择"
                        )
                    )
                else:
                    img = options[number - 1]
                    me.pop("pending", None)
                    if pending.get("kind") == "gacha":
                        # 选中的卡成为今天的老婆（不可更换）
                        cfg = self.load_group_config(gid)
                        cfg[uid] = {
                            "img": img,
                            "date": today,
                            "owner": nick,
                            "locked": True,
                            "source": "gacha",
                        }
                        self.save_group_config(gid, cfg)
                        replies.append(
                            self._build_locked_wife_message(event, img, nick, "自选")
                        )
                    else:
                        me["pickup"] = img
                        # 选定 Pick Up 后同样追问一次是否一并运用至单抽
                        question = self._ask_single_pickup(me, today)
                        replies.append(
                            self._build_reply_message(
                                event, self._pickup_set_message(img)
                            )
                        )
                        replies.append(self._build_reply_message(event, question))
                    self.save_gacha_state(gid, state)

        await self._send_all(matcher, replies)

    # ==================== 定时清理 ====================

    async def _daily_cleanup_loop(self) -> None:
        """每天零点清理跨天失效的历史次数记录"""
        while True:
            try:
                # 多等一分钟，避免时钟误差导致在日期变更前执行
                await asyncio.sleep(seconds_until_next_midnight(self.tz) + 60)
                await self._cleanup_expired_records()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("定时清理过期数据失败")

    async def _cleanup_expired_records(self) -> None:
        """逐群清理历史次数记录（在群锁内执行，避免与处理协程交错）"""
        today = get_today(self.tz)
        changed = False
        for gid in {gid for recs in self.records.values() for gid in recs}:
            async with self.get_group_lock(gid):
                if self._prune_group_records(gid, today):
                    changed = True
        if changed:
            self.save_records()

    def start(self) -> None:
        """插件加载后启动零点清理任务"""
        if self._daily_cleanup_task and not self._daily_cleanup_task.done():
            return
        coro = self._daily_cleanup_loop()
        try:
            self._daily_cleanup_task = asyncio.create_task(coro)
        except RuntimeError:
            # 无运行中的事件循环时关闭协程，避免 "coroutine never awaited" 告警
            coro.close()
            self._daily_cleanup_task = None

    async def shutdown(self) -> None:
        """NoneBot2 关闭 / 插件卸载时停止后台任务（对应 AstrBot 的 terminate）"""
        task = self._daily_cleanup_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


# ==================== 插件注册 ====================

anime_wife = AnimeWife()


def match_command(event: Event) -> str | None:
    """返回消息命中的本插件命令名，未命中返回 None

    **严格匹配**：整条消息必须恰好等于命令名，或为「命令名 + 空格 + 参数」。
    这样「帮我换老婆」「换老婆啊」「xxxx换老婆xxxx」都不会误触发；
    而「查老婆 明日香」这类带参数的正常用法仍然可用。

    两条例外：

    - ``pick up`` / ``更换pick up`` 允许省略参数前的空格（``pick up五河琴里``）；
    - 纯数字消息在「有待选择列表」时命中内部命令 ``__select__``，
      用于从 Pick Up 候选 / 十连结果中做选择。

    另有一条同性质的例外：「是 / 否」在「有待答问题」时命中内部命令 ``__confirm__``，
    用于回答「是否把 Pick Up 角色一并运用到单抽」。两者都要求确实有待处理项才命中，
    不会误吞群里的普通数字或闲聊。

    同时供匹配规则与处理函数使用，避免两处判定逻辑走偏。
    """
    if not _is_group_event(event):
        return None
    text = _extract_text(event)
    if not text:
        return None
    # 数字回复：只有确实有待选择列表时才命中，不误吞群里的普通数字
    if text.isascii() and text.isdigit() and anime_wife.has_pending_selection(event):
        return SELECT_COMMAND
    # 「是 / 否」回答：只有确实有待答问题时才命中，不误吞群里的闲聊
    if _is_confirm_answer(text) and anime_wife.has_pending_confirm(event):
        return CONFIRM_COMMAND
    for cmd in anime_wife.command_names:
        if text == cmd or text.startswith(f"{cmd} "):
            return cmd
        if cmd in ARG_COMMANDS and text.startswith(cmd):
            return cmd
    return None


def _trigger_rule(event: Event) -> bool:
    """只在群聊、且消息严格等于本插件命令时触发

    配合 ``block=False``（默认）实现「各答各的」：本插件答完之后放行事件，
    其它老婆插件仍可对同一条指令各自回应；未命中本插件命令的消息直接跳过，
    完全不影响其它插件处理普通聊天。
    """
    return match_command(event) is not None


anime_wife_matcher = on_message(
    rule=Rule(_trigger_rule),
    priority=plugin_config.command_priority,
    block=plugin_config.block_other_plugins,
)


@anime_wife_matcher.handle()
async def handle_wife_command(matcher: Matcher, bot: Bot, event: Event) -> None:
    """消息分发处理（仅群聊监听）

    bot / event 通过依赖注入获取：NoneBot2 2.5 起 Matcher 不再暴露
    ``matcher.bot`` / ``matcher.event`` 属性。
    """
    cmd = match_command(event)
    if cmd is None:
        return

    if cmd == SELECT_COMMAND:
        await anime_wife.select_pending(event, bot, matcher)
        return

    if cmd == CONFIRM_COMMAND:
        await anime_wife.confirm_single_pickup(event, bot, matcher)
        return

    await anime_wife.commands[cmd](event, bot, matcher)


anime_wife.start()


@get_driver().on_shutdown
async def _() -> None:
    await anime_wife.shutdown()
